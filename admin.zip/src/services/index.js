import _http from "./http";

export const http = _http;
