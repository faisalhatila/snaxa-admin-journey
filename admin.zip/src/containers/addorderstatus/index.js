import React from "react";
import { AddOrderStatusForm } from "../../components";
// let AddOrderStatus;
const AddOrderStatus = (props) => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-12 mt-4">
          <AddOrderStatusForm />
        </div>
      </div>
    </div>
  );
};
export default AddOrderStatus;
