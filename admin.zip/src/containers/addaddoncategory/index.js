import React from "react";
import { AddAddonCategoryForm } from "../../components";
// let AddAddonCategory;
const AddAddonCategory = (props) => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-12 mt-4">
          <AddAddonCategoryForm />
        </div>
      </div>
    </div>
  );
};
export default AddAddonCategory;
