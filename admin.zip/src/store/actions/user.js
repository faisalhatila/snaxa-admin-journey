// import Constants from "../constants";
// import { http } from "../../services";

// const handleLogin = params => {
//   return async (dispatch, getState) => {
//     try {
//     } catch (error) {}
//   };
// };

// export default {
//   handleLogin
// };
